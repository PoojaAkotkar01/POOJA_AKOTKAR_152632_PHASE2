package com.cg.mypaymentapp.exception;

public interface IInsufficientBalanceException {
	String ERROR1 = "Insufficient Balance Cannot Withdraw";
	String ERROR2 = "Insufficient Balance Cannot Transfer";
}
