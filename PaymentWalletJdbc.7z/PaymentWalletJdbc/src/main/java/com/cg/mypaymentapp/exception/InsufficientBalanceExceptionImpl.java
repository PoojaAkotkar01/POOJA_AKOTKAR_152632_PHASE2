package com.cg.mypaymentapp.exception;

public class InsufficientBalanceExceptionImpl extends Exception {
	public InsufficientBalanceExceptionImpl(String msg) {
		super(msg);
	}
	public InsufficientBalanceExceptionImpl() {
		super();
	}
}
