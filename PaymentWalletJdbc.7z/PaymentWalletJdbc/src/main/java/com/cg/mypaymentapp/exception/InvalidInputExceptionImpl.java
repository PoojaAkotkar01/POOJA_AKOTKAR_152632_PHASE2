package com.cg.mypaymentapp.exception;

public class InvalidInputExceptionImpl extends Exception {
	
	public InvalidInputExceptionImpl(String msg) {
		super(msg);
	}
	public InvalidInputExceptionImpl() {
		super();
	}
}
