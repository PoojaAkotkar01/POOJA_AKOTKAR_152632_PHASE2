package com.cg.mypaymentapp.pl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceExceptionImpl;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;
import com.cg.mypaymentapp.repo.WalletRepoImpl;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client {
	static WalletService service = new WalletServiceImpl();
	static int choice1 = 0;
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean check;
		Scanner scanner = new Scanner(System.in);

		int choice = 0;

		do {
			printDetails();
			Customer customer = new Customer();
			System.out.println("Enter Choice");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:

				System.out.println("Enter Name");
				String name = scanner.next();
				System.out.println("Enter Mobile No");
				String mobileNo = scanner.next();
				System.out.println("Enter Balance");
				BigDecimal balance = scanner.nextBigDecimal();
				

				try {
					if (service.inputValidation(name, mobileNo)) {
						customer.setName(name);
						customer.setMobileNo(mobileNo);
						customer.setWallet(balance);
						if(service.checkMobile(mobileNo)==false)
						{
						service.createAccount(customer);
						System.out.println("Account created");
						System.out.println(customer);
						}
						else {
							System.out.println("Customer with this mobile number already exist");
						}
						
					}
			//		service.createAccount(customer);
			//	  System.out.println("Account created");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			

				
			
				break;

			case 2:
				System.out.println("Enter Mobile No.");
				String mobNo = scanner.next();
				try {
				if(service.mobileValidation(mobNo))	{
				
				 check= service.checkMobile(mobNo); 
					 if(check==true) {
					selectOption(mobNo);
				}
				 else{
					System.out.println("Mobile No does not exist");
					}
			}
			}catch (Exception e) {
				System.out.println(e.getMessage());
			}	
			
				break;

			case 3:
				System.exit(0);
				break;
			}
		} while (choice != 3);

	}

	public static void selectOption(String mobNo) throws InvalidInputExceptionImpl, InsufficientBalanceExceptionImpl {
		do {
			printDetails1();
			Customer customer = new Customer();
			System.out.println("Enter Choice");
			choice1 = scanner.nextInt();

			switch (choice1) {

			case 1:
				customer = service.showBalance(mobNo);
				System.out.println(customer);
				break;
			case 2:
				// System.out.println("Enter sender's mobile no");
				// String mobNoS = scanner.next();
				
				System.out.println("Enter receiver's mobile no.");
				String mobNoR = scanner.next();
				try {
					if(service.mobileValidation(mobNoR))	{
						if(service.checkMobile(mobNoR)) {
						System.out.println("Enter the amount to be trasfered");
						BigDecimal amtTrasfer = scanner.nextBigDecimal();
							if(service.transferValidation(amtTrasfer, mobNo)) {
							Customer custreceiver = service.fundTransfer(mobNo, mobNoR, amtTrasfer);
							System.out.println(custreceiver);	}		
					}else {
						System.out.println("Mobile No does not exist");	
					}
				
				}
				}catch (InsufficientBalanceExceptionImpl e) {
					System.out.println(e.getMessage());
					}
				catch (InvalidInputExceptionImpl ex) {
					// TODO: handle exception
					System.out.println(ex.getMessage());
				}
				
				break;
			case 3:

				System.out.println("Enter Amount to be deposited");
				BigDecimal amount = scanner.nextBigDecimal();
				customer = service.depositAmount(mobNo, amount);
			//	System.out.println(cust1);
				System.out.println(customer);

				break;
			case 4:
			
					System.out.println("Enter Amount to be withdrawn");
					BigDecimal amount1 = scanner.nextBigDecimal();
					try {
						if(service.balanceValidation(amount1, mobNo)){
							customer = service.withdrawAmount(mobNo, amount1);
							System.out.println(customer);
						}
				} catch (InvalidInputExceptionImpl e) {
					System.out.println(e.getMessage());
				}
				break;

			case 5:
				ArrayList<String> allData=null;
				try {
				allData = service.printTransactions(mobNo);
			
				for (String string : allData) {
					System.out.println(string);
				}
				}
				catch (InvalidInputExceptionImpl e) {
					System.out.println(e.getMessage());
				}
				
				break;

			case 6:
				new Client();
				break;
			}
		} while (choice1 != 6);

	}

	public static void printDetails() {

		System.out.println("1. Create Account");
		System.out.println("2.Log In");
		System.out.println("3. Exit");
	}

	public static void printDetails1() {

		System.out.println("1. Show Balance");
		System.out.println("2. Fund Transfer");
		System.out.println("3. Deposit Amount");
		System.out.println("4. Withdraw Amount");
		System.out.println("5  Print transactions");
		System.out.println("6  Log out");
	}
}
