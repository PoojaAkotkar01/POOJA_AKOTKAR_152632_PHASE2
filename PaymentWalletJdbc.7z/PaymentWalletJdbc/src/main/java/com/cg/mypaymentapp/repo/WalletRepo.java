package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceExceptionImpl;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;

public interface WalletRepo {

	public String save(Customer customer);
	public Customer findOne(String mobileNo) throws InvalidInputExceptionImpl;
	public boolean checkMobile(String mobileNo) throws InvalidInputExceptionImpl;
	public void addTransactions(String mobileNo,String transaction);
	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputExceptionImpl;
	public void updateWallet(String mobileNo, BigDecimal amount);
}
