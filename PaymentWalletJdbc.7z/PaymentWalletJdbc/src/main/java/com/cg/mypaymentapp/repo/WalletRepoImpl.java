package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.mypaymentapp.util.TestConnection;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;

public class WalletRepoImpl implements WalletRepo {
	Connection con = null;
	// private static Map<String, Customer> data;

	public WalletRepoImpl() {
		// TODO Auto-generated constructor stub
		try {
			con = TestConnection.getConnect();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String save(Customer customer) {

		// TODO Auto-generated method stub
		// String mobileNo=null;
		// mobileNo = getMobNo();
		try {
			String sql = "INSERT INTO customer_details VALUES(?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setString(1, customer.getMobileNo());
			pstmt.setString(2, customer.getName());
			pstmt.setBigDecimal(3, customer.getWallet());

			pstmt.executeUpdate();
		} catch (SQLException e) {

			
		}

		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) throws InvalidInputExceptionImpl {

		Customer customer = new Customer();

		try {
			String sql = "SELECT * FROM customer_details WHERE custmobileno= ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			if (res.next() == true) {

				customer.setMobileNo(res.getString(1));
				customer.setName(res.getString(2));
				customer.setWallet(res.getBigDecimal(3));
			} else {
				throw new InvalidInputExceptionImpl(IInvalidInputException.ERROR3);
			}
		} catch (Exception e) {

		}
		return customer;

	}

	public boolean checkMobile(String mobileNo) throws InvalidInputExceptionImpl {
		boolean flag = false;
		String query = "SELECT * FROM customer_details  WHERE custmobileno = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			if (res.next())
				flag = true;
			else
			{
				throw new InvalidInputExceptionImpl(IInvalidInputException.ERROR3);
			}
		} catch (SQLException e) {
		}
		return flag;

	}

	public void addTransactions(String mobileNo, String transaction) {
		try {
			String sql = "INSERT INTO TRANSACTION VALUES(?, ?)";

			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			pstmt.setString(2, transaction);
			pstmt.executeUpdate();

		} catch (Exception e) {

		}

	}

	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputExceptionImpl {
		ArrayList<String> transactionList = new ArrayList<String>();
		String sql = "SELECT * FROM TRANSACTION WHERE MOBILE= ?";
		try {

			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			
				while (res.next()) {
					transactionList.add(res.getString(2));
				}
				
		} catch (Exception e) {

		}
		return transactionList;

	}

	public void updateWallet(String mobileNo, BigDecimal amount) {
		try {
			String sql = "UPDATE customer_details SET custbalance= ? WHERE custmobileno= ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setBigDecimal(1, amount);
			pstmt.setString(2, mobileNo);

			pstmt.executeUpdate();

		} catch (Exception e) {

		}

	}


}
