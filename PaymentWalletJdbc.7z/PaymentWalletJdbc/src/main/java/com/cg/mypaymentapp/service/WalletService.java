package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceExceptionImpl;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;

public interface WalletService {
	public void createAccount(Customer customer);
	public Customer showBalance (String mobileno) throws InvalidInputExceptionImpl;
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) throws InvalidInputExceptionImpl;
	public Customer depositAmount (String mobileNo,BigDecimal amount ) throws InvalidInputExceptionImpl;
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InvalidInputExceptionImpl;
	public boolean inputValidation(String name,String mobile)throws InvalidInputExceptionImpl;
	public boolean balanceValidation(BigDecimal amount,String mobNo) throws InsufficientBalanceExceptionImpl, InvalidInputExceptionImpl;
	public boolean mobileValidation(String mobile)throws InvalidInputExceptionImpl;
	public boolean transferValidation(BigDecimal amount,String mobNoS) throws InsufficientBalanceExceptionImpl, InvalidInputExceptionImpl;
	public boolean checkMobile(String mobileNo) throws InvalidInputExceptionImpl;
	public Customer findOne(String mobNo) throws InvalidInputExceptionImpl;
	public ArrayList<String>printTransactions(String mobileNo) throws InvalidInputExceptionImpl;
}
