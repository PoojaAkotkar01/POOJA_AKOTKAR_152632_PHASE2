package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.IInsufficientBalanceException;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceExceptionImpl;
import com.cg.mypaymentapp.exception.InvalidInputExceptionImpl;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo repo = null;

	public WalletServiceImpl() {
		// TODO Auto-generated constructor stub
		repo = new WalletRepoImpl();
	}

	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		
		repo.save(customer);
	

	}
	
	public boolean checkMobile(String mobileNo) throws InvalidInputExceptionImpl {
		// TODO Auto-generated method stub
		return repo.checkMobile(mobileNo);
	}

	public Customer findOne(String mobileNo) throws InvalidInputExceptionImpl
	{
		return repo.findOne(mobileNo);
		
	}

	public Customer showBalance(String mobileNo) throws InvalidInputExceptionImpl {
		// TODO Auto-generated method stub
		// Map<String, Customer> customerDetails = repo.getDetails();
		Customer cust2 = repo.findOne(mobileNo); 
		return	cust2;
		
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputExceptionImpl {
		// TODO Auto-generated method stub
		 Customer senderDetails = repo.findOne(sourceMobileNo);
		 Customer receiverDetails = repo.findOne(targetMobileNo);
		
		BigDecimal senderBal = senderDetails.getWallet();
		senderBal = senderBal.subtract(amount);
		senderDetails.setWallet(senderBal);
		repo.updateWallet(sourceMobileNo, senderBal);
		
		BigDecimal receiverBal = receiverDetails.getWallet();
		receiverBal = receiverBal.add(amount);
		receiverDetails.setWallet(receiverBal);
		repo.updateWallet(targetMobileNo, receiverBal);
		repo.addTransactions(sourceMobileNo,amount+" Amount Transfered from "+sourceMobileNo+" to "+targetMobileNo+ " Current balance "+senderBal+" at "+LocalDateTime.now());
	//	repo.addTransactions(targetMobileNo,amount+" Amount Transfered from "+sourceMobileNo+" to "+targetMobileNo+ " Current balance "+receiverBal+" at"+LocalDateTime.now());
		
		return senderDetails;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputExceptionImpl {
		
		Customer cust = repo.findOne(mobileNo);
	
		BigDecimal finalAmt = cust.getWallet().add(amount);
		cust.setWallet(finalAmt);
		repo.updateWallet(mobileNo, finalAmt);
		
		repo.addTransactions(mobileNo,amount+" Deposited to "+mobileNo+" Current balance "+finalAmt+" at"+LocalDateTime.now());
		
		return cust;

	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InvalidInputExceptionImpl {
	
		Customer cust1 = repo.findOne(mobileNo);
		BigDecimal finalAmt1 = cust1.getWallet().subtract(amount);
		cust1.setWallet(finalAmt1);
		repo.updateWallet(mobileNo, finalAmt1);
		repo.addTransactions(mobileNo,amount+"  Withdrawn from "+mobileNo+" Current balance "+finalAmt1+" at"+LocalDateTime.now());
		return cust1;
		
	}

	
	
	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputExceptionImpl {
	 return repo.printTransactions(mobileNo);	
	}
	
	
	
	public boolean inputValidation(String name,String mobile)throws InvalidInputExceptionImpl {
		boolean result = false;
		if(name.trim().matches("^[A-Z a-z]*$")) {
			
			if(mobile.length()==10 && mobile.matches("[0-9]+")) {
				result = true;
			}
			else {
				throw new InvalidInputExceptionImpl(IInvalidInputException.ERROR1);
			}
			
		}	else {
				throw new InvalidInputExceptionImpl(IInvalidInputException.ERROR2);
			}
		
		return result;
		
	}
	
	public boolean balanceValidation(BigDecimal amount,String mobNo) throws InsufficientBalanceExceptionImpl, InvalidInputExceptionImpl{
		boolean result = false;
		BigDecimal balance = repo.findOne(mobNo).getWallet();
			if(amount.compareTo(balance) == -1 ) {             // balance is grater than amount
			result=true;
			}
			else
			{
				throw new InsufficientBalanceExceptionImpl(IInsufficientBalanceException.ERROR1);
			}
		
		return result;
		
	}
	
	public boolean mobileValidation(String mobile)throws InvalidInputExceptionImpl {
		boolean result = false;
			if(mobile.length()==10) {
				result = true;
	
			}else {
				throw new InvalidInputExceptionImpl(IInvalidInputException.ERROR1);
			}

		return result;
		
	}
	
	public boolean transferValidation(BigDecimal amount, String mobNoS) throws InsufficientBalanceExceptionImpl, InvalidInputExceptionImpl{
		boolean result = false;
		BigDecimal bal1 = repo.findOne(mobNoS).getWallet();
		
			if(amount.compareTo(bal1) == -1) {
			result=true;
			}
			else
			{
				throw new InsufficientBalanceExceptionImpl(IInsufficientBalanceException.ERROR2);
			}
		
		return result;
		
	}

	  


}
